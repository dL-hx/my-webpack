class CopyrightWebpackPlugin {
    apply(compiler) {
        compiler.hooks.compile.tap('CopyrightWebpackPlugin', (compilation) => {
            console.log('compiler')
        });
        // 指定要附加到的事件钩子函数
        compiler.hooks.emit.tapAsync('CopyrightWebpackPlugin',
            (compilation, callback) => {// 使用 webpack 提供的 plugin API 操作构建结果
                // compilation.addModule(/* ... */);
                compilation.assets['copyright.txt'] = {
                    source:function () {
                        return 'copyright by dell lee'
                    },
                    size:function () {
                        return 21
                    }
                }
                callback();
            }
        );
    }
}

module.exports = CopyrightWebpackPlugin