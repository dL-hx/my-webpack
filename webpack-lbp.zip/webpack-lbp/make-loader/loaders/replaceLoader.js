module.exports = function (source) {
    return source.replace('lee', 'world');
}
