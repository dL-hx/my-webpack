const fs = require('fs');
const path = require('path');
const parser = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const babel = require('@babel/core');
// 读取入口文件
// 对入口文件分析模块
const moduleAnalyser = (filename) => {
    const content = fs.readFileSync(filename, 'utf-8')
    const ast = parser.parse(content, {
        sourceType: 'module'
    });

    const dependencies = {}

    traverse(ast, {
        //提取哪个字段就用哪个函数
        ImportDeclaration({node}) {
            // console.log(node.source.value)
            //路径拼接
            const newFile = "./" + path.join(path.dirname(filename), node.source.value)
            dependencies[node.source.value] = newFile
        }
    })

    const {code} = babel.transformFromAst(ast, null, {
        presets: ['@babel/preset-env']
    })

    // console.log(code)
    // console.log(dependencies)
    // console.log(content)
    return {
        filename,
        dependencies,//如果没有值，说明没有依赖
        code
    }
}

const makeDependenciesGraph = (entry) => {
    const entryModule = moduleAnalyser(entry);
    const graphArray = [entryModule]
    for (let i = 0; i < graphArray.length; i++) {
        const item = graphArray[i]
        const {dependencies} = item
        if (dependencies) {
            for (let j in dependencies) {
                graphArray.push(moduleAnalyser(dependencies[j]))//分析每个子模块的依赖
            }
        }
    }
    const graph = {}
    graphArray.forEach((item) => {
        graph[item.filename] = {
            dependencies: item.dependencies,
            code: item.code,
        }
    })
    // console.log(graph);
    return graph
};

const generatorCode = (entry) => {
    // console.log(makeDependenciesGraph(entry))
    const graph = JSON.stringify(makeDependenciesGraph(entry));
    return `
        (function (graph) {
            function require(module){
                function localRequire(relativePath){
                  return require(graph[module].dependencies[relativePath])      
                };
                
                var exports = {};
                (function (require,exports, code){
                    eval(code)
                })(localRequire, exports, graph[module].code);
                
                return exports;
            }
           
            require('${entry}')
        })(${graph});
    `
}

const code = generatorCode('./src/index.js')
console.log(code);
