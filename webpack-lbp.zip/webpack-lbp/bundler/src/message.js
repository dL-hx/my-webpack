import {word} from './word.js'

const message = `say ${word}`

export default message